import express from "express";
import authRouter from "./routes/auth.routes.js";
import cookieParser from "cookie-parser";
import config from "./config/config.js";
import interviewRouter from "./routes/interview.routes.js"
import cors from "cors"
const app = express();
const allowedOrigins = (config.CORS_ORIGIN || "http://localhost:5173")
    .split(",")
    .map((origin) => origin.trim())
    .filter(Boolean);

app.use(express.json());
app.use(cookieParser());
app.use(cors({
    origin: (origin, callback) => {
        if (!origin || allowedOrigins.includes(origin)) {
            callback(null, true);
            return;
        }

        callback(new Error("Not allowed by CORS"));
    },
    credentials: true,
}));

app.use('/api/auth', authRouter);
app.use('/api/interview', interviewRouter);

app.get("/", (req, res) => {
    res.status(200).json({
        message: "Resume Backend API is running 🚀"
    });
});




export default app;